#!/usr/bin/bash

# Just kicks off the specpattern process example in a terminal.
/usr/bin/gnome-terminal -e /usr/share/specpattern/specpattern-process.sh
