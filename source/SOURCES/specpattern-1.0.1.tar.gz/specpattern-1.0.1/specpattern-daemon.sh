#!/usr/bin/bash

# I need to truly daemonize this. Not done yet. I need to look up how that is done.
/usr/share/specpattern/specpattern-process.sh
